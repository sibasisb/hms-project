package com.project.hospitalmanagementbackend.exception;

public class TestResultNotFoundException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public TestResultNotFoundException(String msg)
	{
		super(msg);
	}
}
