package com.project.hospitalmanagementbackend.exception;

public class InvalidUserException extends RuntimeException {

	public InvalidUserException(String msg)
	{
		super(msg);
	}
}
